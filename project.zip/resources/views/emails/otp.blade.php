<!DOCTYPE html>
<html>
<head>
    <title>Verification Code</title>
</head>
<body style="font-family: Arial, sans-serif; padding: 20px;">
    <h2>Hello!</h2>
    <p>Your verification code for TechNode is:</p>
    <h1 style="color: #4F46E5; letter-spacing: 5px;">{{ $otp }}</h1>
    <p>Do not share this code with anyone.</p>
</body>
</html>