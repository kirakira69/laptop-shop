

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <h1 class="text-3xl font-bold text-gray-800">User Details</h1>
    <a href="<?php echo e(route('admin.users.index')); ?>" class="text-gray-600 hover:text-gray-900 font-medium">&larr; Back to Users</a>
</div>

<div class="bg-white shadow-lg rounded-xl overflow-hidden">
    <div class="bg-gradient-to-r from-indigo-600 to-blue-500 px-6 py-4">
        <div class="flex justify-between items-center">
            <h2 class="text-white text-xl font-bold"><?php echo e($user->name); ?></h2>
            <span class="px-3 py-1 rounded-full text-xs font-bold bg-white 
                <?php echo e($user->status === 'active' ? 'text-green-600' : 'text-red-600'); ?>">
                <?php echo e(ucfirst($user->status)); ?>

            </span>
        </div>
        <p class="text-indigo-100 text-sm mt-1"><?php echo e($user->email); ?></p>
    </div>

    <div class="p-6">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            
            <div>
                <h3 class="text-gray-500 text-xs font-bold uppercase tracking-wider mb-4 border-b pb-2">Personal Information</h3>
                
                <div class="space-y-4">
                    <div>
                        <label class="text-sm text-gray-500">Role</label>
                        <p class="font-medium text-gray-900"><?php echo e($user->is_admin ? 'Administrator' : 'Customer'); ?></p>
                    </div>
                    <div>
                        <label class="text-sm text-gray-500">Phone Number</label>
                        <p class="font-medium text-gray-900"><?php echo e($user->phone ?? 'N/A'); ?></p>
                    </div>
                    <div>
                        <label class="text-sm text-gray-500">Birthday</label>
                        <p class="font-medium text-gray-900"><?php echo e($user->birthdate ? \Carbon\Carbon::parse($user->birthdate)->format('F d, Y') : 'N/A'); ?></p>
                    </div>
                    <div>
                        <label class="text-sm text-gray-500">Joined Date</label>
                        <p class="font-medium text-gray-900"><?php echo e($user->created_at->format('M d, Y')); ?></p>
                    </div>
                </div>
            </div>

            <div>
                <h3 class="text-gray-500 text-xs font-bold uppercase tracking-wider mb-4 border-b pb-2">Address / Shipping</h3>
                
                <div class="space-y-4">
                    <div>
                        <label class="text-sm text-gray-500">Street / Zone</label>
                        <p class="font-medium text-gray-900">
                            <?php echo e($user->street ?? ''); ?> <?php echo e($user->zone ? '(Zone: '.$user->zone.')' : ''); ?>

                            <?php echo e(!$user->street && !$user->zone ? 'N/A' : ''); ?>

                        </p>
                    </div>
                    <div>
                        <label class="text-sm text-gray-500">Barangay</label>
                        <p class="font-medium text-gray-900"><?php echo e($user->barangay ?? 'N/A'); ?></p>
                    </div>
                    <div>
                        <label class="text-sm text-gray-500">Municipality / City</label>
                        <p class="font-medium text-gray-900"><?php echo e($user->municipal ?? 'N/A'); ?></p>
                    </div>
                    <div>
                        <label class="text-sm text-gray-500">Province & Zip</label>
                        <p class="font-medium text-gray-900">
                            <?php echo e($user->province ?? ''); ?> <?php echo e($user->zip_code ?? ''); ?>

                            <?php echo e(!$user->province && !$user->zip_code ? 'N/A' : ''); ?>

                        </p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laptop-shop\resources\views/admin/users/show.blade.php ENDPATH**/ ?>