

<?php $__env->startSection('content'); ?>
<h1 class="text-3xl font-bold text-gray-800 mb-6">Manage Users</h1>

<div class="bg-white shadow-md rounded-lg overflow-hidden">
    <table class="min-w-full bg-white">
        <thead class="bg-gray-800 text-white">
            <tr>
                <th class="py-3 px-4 text-left">Name</th>
                <th class="py-3 px-4 text-left">Email</th>
                <th class="py-3 px-4 text-left">Role</th>
                <th class="py-3 px-4 text-left">Status</th>
                <th class="py-3 px-4 text-left">Action</th>
            </tr>
        </thead>
        <tbody class="text-gray-700">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-b hover:bg-gray-50">
                <td class="py-3 px-4 font-bold"><?php echo e($user->name); ?></td>
                <td class="py-3 px-4"><?php echo e($user->email); ?></td>
                <td class="py-3 px-4">
                    <?php if($user->is_admin): ?>
                        <span class="bg-purple-100 text-purple-800 text-xs font-bold px-2 py-1 rounded">Admin</span>
                    <?php else: ?>
                        <span class="bg-gray-100 text-gray-800 text-xs font-bold px-2 py-1 rounded">Customer</span>
                    <?php endif; ?>
                </td>
                <td class="py-3 px-4">
                    <?php if($user->status === 'active'): ?>
                        <span class="bg-green-100 text-green-800 text-xs font-bold px-2 py-1 rounded">Active</span>
                    <?php else: ?>
                        <span class="bg-red-100 text-red-800 text-xs font-bold px-2 py-1 rounded">Disabled</span>
                    <?php endif; ?>
                </td>
                <td class="py-3 px-4">
                    <a href="<?php echo e(route('admin.users.show', $user->id)); ?>" class="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold py-1 px-3 rounded shadow transition">
                          View
                            </a>

                        
                    <br><form action="<?php echo e(route('admin.users.toggle', $user->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>

                        <?php if($user->status === 'active'): ?>
                            <button type="submit" class="bg-red-500 hover:bg-red-600 text-white text-xs font-bold py-1 px-3 rounded shadow transition">
                                Disable Account
                            </button>
                        <?php else: ?>
                            <button type="submit" class="bg-green-500 hover:bg-green-600 text-white text-xs font-bold py-1 px-3 rounded shadow transition">
                                Enable Account
                            </button>
                        <?php endif; ?>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="p-4">
        <?php echo e($users->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laptop-shop\resources\views/admin/users/index.blade.php ENDPATH**/ ?>