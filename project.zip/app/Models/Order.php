<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'order_number',
        'status',
        'grand_total',
        'payment_status',
        'payment_method',
        'shipping_address',
    ];

    // --- 1. THIS WAS MISSING (Fixes the error) ---
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    // --- 2. Relationship to items ---
    public function items()
    {
        return $this->hasMany(OrderItem::class);
    }
}